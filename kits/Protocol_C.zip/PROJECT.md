# Project brief

This is a template, not accepted evidence. Fill it in before relying on its claims. Existing user instructions and authorizations remain valid.

## Selected framework

- Protocol: Protocol_C, framework edition 1, installed as PROTOCOL.md.
- Protocol file SHA-256:
- Completion claim that this project intends to earn:
- Any explicitly approved departure, and how the resulting status must be labeled:

Do not downgrade or expand the framework silently. A departure must remain visible in the final status.

## Mathematical target

- Exact theorem, counterexample, construction or computational objective:
- Ambient objects, quantifiers and parameter ranges:
- Required degree, size, complexity or other quantitative bounds:
- Intended artifact representation and recoverability:
- Conditional assumptions, if the target is intentionally conditional:
- Explicit exclusions from the target:
- Initial manuscript, sources and useful existing results:

## Trust and review

- Known objections, disputed sources and source-access limitations:
- Canonical ledger location: REVIEW_LEDGER.md, or:
- Unit boundaries and stable identifier convention:
- Author and integration owner:
- Required reviewers and their scopes under the selected framework:
- Existing accepted evidence and the exact versions it covers:
- Criteria for closing each task and the overall target:

## Release contract

- Repository, branch and authorized publication destinations:
- Required manuscript and artifact filenames:
- Version and date conventions:
- Reproduction commands and required environments:
- Current artifact index and inventory locations:
- Cumulative handoff path, archive policy and intended contents:
- Provenance, credit, redistribution permissions and access restrictions:
- Public/private destination differences and required readback:
- Required links and checks:

## Minimal release plan

- Immutable candidate commit and artifact manifest; derived hosting metadata checked separately:
- Ordered stages, commands, dependencies, owners and saved success records; exact inputs and checker/configuration versions that permit reuse:
- End-to-end preflight, existing signed-evidence compatibility if applicable, failure/retry cases, and live-only checks still pending:
- Measured or estimated time, compute and storage budget per phase; progress/error reporting location and recovery owner:
- Short publication and readback steps under existing authorization; safe resume point after partial publication:

## Resources and existing authorization

- Time, compute, memory and concurrency constraints:
- Already authorized parallel work and external services:
- Already authorized publication, messages, purchases or access changes:
- Sensitive files and excluded source material:
- Decisions genuinely requiring the owner's input:

## First checkpoint

Give the mathematical plan, main uncertainty, next useful proof or review task, minimal record structure and integration owner. This is not an extra approval gate unless the owner requires one. Begin useful research while completing this setup.
