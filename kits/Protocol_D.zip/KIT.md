# Protocol_D starter kit

Exact Protocol 1.4. Framework edition 1, November 9, 2026.

Preserve every Protocol 1.4 requirement, including independent source-first reconstruction, reconciliation, distinct application, coverage and assembly decisions, related-use review, and release maintenance.

Read PROTOCOL.md for the complete requirements. AGENTS.md is the operating guide, PROJECT.md is the project brief to fill in, and REVIEW_LEDGER.md is an empty evidence template. A blank template or this kit's manifest is not proof that a research project satisfies the protocol.

Copy the five Markdown files into a new research repository. For an existing repository, merge deliberately without overwriting project records or prior authorizations. Keep the original kit MANIFEST.json as provenance if useful; it lists template hashes and does not describe the filled-in research release.

Start with the mathematical objective and minimal records. Stop after the chosen protocol's actual completion requirements pass. Record limitations and unresolved work honestly. This kit does not authorize external publication or communication.

## Role definitions

An author is the producer of the particular argument, construction or code under review: a human, an AI agent, or a collaboration. This task-specific role does not decide publication authorship. A reviewer examines that contribution; required non-author acceptance must come from a person or agent that did not produce it. A separate AI agent can provide non-author review without requiring a second human operator. Repeating a check by the same agent is not independent review. Record prior exposure, shared context and any repair contributed by the reviewer, and follow PROTOCOL.md's specific independence requirements. Distinct identities do not guarantee independent reasoning.

The project owner sets the objective, chooses the framework and authorizes publication. The integrator combines accepted contributions and checks compatibility. Roles may differ from one contribution to another.
